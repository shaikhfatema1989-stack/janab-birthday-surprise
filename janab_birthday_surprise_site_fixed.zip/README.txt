JANAB BIRTHDAY SURPRISE
=======================

Files:
- index.html
- assets/our_little_story.gif

The site is a static website and needs no paid service or build step.
Secret password: 14.10

To publish free:
1. Open https://app.netlify.com/drop in a browser.
2. Sign in or create a free Netlify account if asked.
3. Upload the ZIP file (or unzip it and upload the folder).
4. Netlify will publish the site and give you a shareable link.

Keep the whole folder structure together. Do not upload only index.html;
the GIF is in the assets folder.
